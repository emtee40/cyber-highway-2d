To compile Windows version, remove the relevent comment tags for you OS and target.

Before running a compiled windows version add the relevent SDL files depending on the system you're using.

This build has been provided with pre-compiled 32bit and 64bit binaries for Windows and Linux and the nessasary files for the game to run. The Windows builds and the SDL folders include the nessasary dll files for the game to run. I am not the creator or the copyright holder of any of these dlls and they belong to their respective parties.


Early work on the project started with the help of this tutorial:

https://www.youtube.com/watch?v=yFLa3ln16w0 - Writing 2D Games in C using SDL by Thomas Lively - Uploader CS50
